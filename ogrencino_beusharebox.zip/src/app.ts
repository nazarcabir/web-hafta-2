/**
 * BEUShareBox - Sınıf Projesi (Gelişmiş Versiyon)
 * Bu dosya uygulamanın tüm mantığını (logic) içerir.
 * Saf (vanilla) TypeScript/JavaScript ile yazılmıştır.
 */

interface Yorum {
  id: string;
  metin: string;
  zamanDamgasi: number;
}

interface Urun {
  id: string;
  baslik: string;
  aciklama: string;
  fiyat: number;
  kategori: string;
  begeniSayisi: number;
  yorumlar: Yorum[];
  olusturulmaTarihi: number;
  resim?: string; // Base64 formatında görsel
}

class ShareBoxApp {
  private urunler: Urun[] = [];
  private filtrelenmisUrunler: Urun[] = [];
  private mevcutKategori: string = 'all';
  private aramaSorgusu: string = '';
  private siralamaKriteri: string = 'newest';

  constructor() {
    this.baslat();
  }

  private baslat() {
    this.verileriYukle();
    this.temaYukle();
    this.olayDinleyicileriKur();
    this.filtreleriUygula();
  }

  // LocalStorage'dan verileri çeker
  private verileriYukle() {
    const kaydedilmis = localStorage.getItem('beu_sharebox_urunler');
    if (kaydedilmis) {
      try {
        this.urunler = JSON.parse(kaydedilmis);
      } catch (e) {
        console.error('Veri yükleme hatası', e);
        this.urunler = [];
      }
    } else {
      // Örnek veriler (10 Adet Görsel İçeren Veri)
      this.urunler = [
        {
          id: '1',
          baslik: 'Premium Kablosuz Kulaklık',
          aciklama: 'Gürültü engelleme özelliği ve kristal netliğinde ses kalitesi ile müzik keyfini zirveye taşıyın.',
          fiyat: 1250,
          kategori: 'Elektronik',
          begeniSayisi: 24,
          yorumlar: [{ id: 'c1', metin: 'Ses kalitesi muazzam!', zamanDamgasi: Date.now() }],
          olusturulmaTarihi: Date.now() - 100000,
          resim: 'https://picsum.photos/seed/audio/400/300'
        },
        {
          id: '2',
          baslik: 'Minimalist Çalışma Lambası',
          aciklama: 'Göz yormayan LED teknolojisi ve şık tasarımıyla masanıza estetik bir dokunuş katın.',
          fiyat: 320,
          kategori: 'Ev',
          begeniSayisi: 15,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 200000,
          resim: 'https://picsum.photos/seed/lamp/400/300'
        },
        {
          id: '3',
          baslik: 'Vintage Deri Ceket',
          aciklama: 'Hakiki deri, el işçiliği ile üretilmiş zamansız bir parça. Her kombine uyum sağlar.',
          fiyat: 2400,
          kategori: 'Moda',
          begeniSayisi: 42,
          yorumlar: [{ id: 'c2', metin: 'Kalıbı harika.', zamanDamgasi: Date.now() }],
          olusturulmaTarihi: Date.now() - 300000,
          resim: 'https://picsum.photos/seed/jacket/400/300'
        },
        {
          id: '4',
          baslik: 'Modern Sanat Tablosu',
          aciklama: 'Soyut figürlerin dansı. Evinizin enerjisini değiştirecek özel bir kanvas tablo.',
          fiyat: 850,
          kategori: 'Ev',
          begeniSayisi: 8,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 400000,
          resim: 'https://picsum.photos/seed/art/400/300'
        },
        {
          id: '5',
          baslik: 'Akıllı Saat Pro',
          aciklama: 'Sağlık takibi, uyku analizi ve spor modları ile hayatınızı kolaylaştıran teknoloji.',
          fiyat: 1800,
          kategori: 'Elektronik',
          begeniSayisi: 31,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 500000,
          resim: 'https://picsum.photos/seed/watch/400/300'
        },
        {
          id: '6',
          baslik: 'İpek Şal - Gül Kurusu',
          aciklama: '%100 saf ipekten üretilmiş, yumuşak dokusuyla zarafetinizi tamamlayacak bir aksesuar.',
          fiyat: 450,
          kategori: 'Moda',
          begeniSayisi: 19,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 600000,
          resim: 'https://picsum.photos/seed/silk/400/300'
        },
        {
          id: '7',
          baslik: 'Seramik Kahve Takımı',
          aciklama: 'El yapımı 2 kişilik kahve fincanı seti. Sabah kahveleriniz artık daha keyifli.',
          fiyat: 280,
          kategori: 'Ev',
          begeniSayisi: 27,
          yorumlar: [{ id: 'c3', metin: 'Hediye olarak aldım, çok beğenildi.', zamanDamgasi: Date.now() }],
          olusturulmaTarihi: Date.now() - 700000,
          resim: 'https://picsum.photos/seed/coffee/400/300'
        },
        {
          id: '8',
          baslik: 'Dünya Klasikleri Seti',
          aciklama: 'En sevilen 5 dünya klasiği bir arada. Kütüphanenizin baş köşesinde yer alacak.',
          fiyat: 190,
          kategori: 'Kitap',
          begeniSayisi: 55,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 800000,
          resim: 'https://picsum.photos/seed/books/400/300'
        },
        {
          id: '9',
          baslik: 'Retro Fotoğraf Makinesi',
          aciklama: 'Anılarınızı ölümsüzleştirin. Hem dekoratif hem de fonksiyonel analog makine.',
          fiyat: 1100,
          kategori: 'Elektronik',
          begeniSayisi: 14,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 900000,
          resim: 'https://picsum.photos/seed/camera/400/300'
        },
        {
          id: '10',
          baslik: 'Tasarım Günlük Defter',
          aciklama: 'Düşüncelerinizi, planlarınızı ve hayallerinizi yazmanız için özel tasarım çizgili defter.',
          fiyat: 75,
          kategori: 'Diğer',
          begeniSayisi: 22,
          yorumlar: [],
          olusturulmaTarihi: Date.now() - 1000000,
          resim: 'https://picsum.photos/seed/notebook/400/300'
        }
      ];
      this.verileriKaydet();
    }
  }

  private verileriKaydet() {
    localStorage.setItem('beu_sharebox_urunler', JSON.stringify(this.urunler));
  }

  private temaYukle() {
    const tema = localStorage.getItem('beu_theme') || 'light';
    document.documentElement.setAttribute('data-theme', tema);
  }

  private olayDinleyicileriKur() {
    // Ürün Ekleme Formu
    const form = document.getElementById('productForm') as HTMLFormElement;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.urunEkle(form);
    });

    // Arama Çubuğu
    const aramaInput = document.getElementById('searchInput') as HTMLInputElement;
    aramaInput.addEventListener('input', (e) => {
      this.aramaSorgusu = (e.target as HTMLInputElement).value.toLowerCase();
      this.filtreleriUygula();
    });

    // Kategori Sekmeleri (Tabs)
    const tabContainer = document.getElementById('categoryTabs') as HTMLElement;
    tabContainer.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      if (target.classList.contains('tab-btn')) {
        // Aktif sınıfını güncelle
        tabContainer.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        target.classList.add('active');
        
        this.mevcutKategori = target.getAttribute('data-category') || 'all';
        this.filtreleriUygula();
      }
    });

    // Sıralama Seçenekleri
    const siralamaSecenek = document.getElementById('sortOptions') as HTMLSelectElement;
    siralamaSecenek.addEventListener('change', (e) => {
      this.siralamaKriteri = (e.target as HTMLSelectElement).value;
      this.filtreleriUygula();
    });

    // Tema Değiştirme
    const temaButon = document.getElementById('themeToggle') as HTMLButtonElement;
    temaButon.addEventListener('click', () => {
      const mevcut = document.documentElement.getAttribute('data-theme');
      const yeni = mevcut === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', yeni);
      localStorage.setItem('beu_theme', yeni);
    });

    // --- DIŞA AKTARMA (PDF Madde 8) ---
    const exportBtn = document.getElementById('exportBtn') as HTMLButtonElement;
    exportBtn.addEventListener('click', () => {
      const dataStr = JSON.stringify(this.urunler, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'BEUShareBox_Veriler.json';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      this.showToast('Veriler JSON olarak indirildi!');
    });

    // --- EVENT DELEGATION (PDF Teknik İpucu) ---
    // Tüm ürün kartı olaylarını tek bir merkezden yönetiyoruz
    const urunGrid = document.getElementById('productGrid') as HTMLElement;
    urunGrid.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      const kart = target.closest('article');
      if (!kart) return;
      const urunId = kart.getAttribute('data-id')!;

      // Beğeni Butonu
      if (target.closest('.like-btn')) {
        this.begeniYap(urunId);
      }
      
      // Silme Butonu
      if (target.closest('.delete-btn')) {
        this.urunSil(urunId);
      }
    });

    // Yorum Formları için Delegasyon
    urunGrid.addEventListener('submit', (e) => {
      const target = e.target as HTMLFormElement;
      if (target.classList.contains('comment-form')) {
        e.preventDefault();
        const kart = target.closest('article');
        const urunId = kart?.getAttribute('data-id')!;
        const input = target.querySelector('.comment-input') as HTMLInputElement;
        this.yorumEkle(urunId, input.value);
        input.value = '';
      }
    });
  }

  private async urunEkle(form: HTMLFormElement) {
    const baslik = (document.getElementById('title') as HTMLInputElement).value;
    const aciklama = (document.getElementById('description') as HTMLTextAreaElement).value;
    const fiyat = parseFloat((document.getElementById('price') as HTMLInputElement).value);
    const kategori = (document.getElementById('category') as HTMLSelectElement).value;
    const resimInput = document.getElementById('imageInput') as HTMLInputElement;

    let resimBase64 = '';
    if (resimInput.files && resimInput.files[0]) {
      resimBase64 = await this.resimOku(resimInput.files[0]);
    }

    const yeniUrun: Urun = {
      id: Date.now().toString(),
      baslik,
      aciklama,
      fiyat,
      kategori,
      begeniSayisi: 0,
      yorumlar: [],
      olusturulmaTarihi: Date.now(),
      resim: resimBase64 || undefined
    };

    this.urunler.unshift(yeniUrun);
    this.verileriKaydet();
    form.reset();
    this.showToast('Ürün başarıyla eklendi!', 'success');
    this.filtreleriUygula();
  }

  private resimOku(file: File): Promise<string> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.readAsDataURL(file);
    });
  }

  private filtreleriUygula() {
    // Filtreleme
    let sonuc = this.urunler.filter(u => {
      const kategoriUygun = this.mevcutKategori === 'all' || u.kategori === this.mevcutKategori;
      const aramaUygun = u.baslik.toLowerCase().includes(this.aramaSorgusu) || 
                         u.aciklama.toLowerCase().includes(this.aramaSorgusu);
      return kategoriUygun && aramaUygun;
    });

    // Sıralama
    sonuc.sort((a, b) => {
      switch (this.siralamaKriteri) {
        case 'priceAsc': return a.fiyat - b.fiyat;
        case 'priceDesc': return b.fiyat - a.fiyat;
        case 'likes': return b.begeniSayisi - a.begeniSayisi;
        case 'newest': default: return b.olusturulmaTarihi - a.olusturulmaTarihi;
      }
    });

    this.filtrelenmisUrunler = sonuc;
    this.ekranaBas();
  }

  private begeniYap(id: string) {
    const urun = this.urunler.find(u => u.id === id);
    if (urun) {
      urun.begeniSayisi++;
      this.verileriKaydet();
      this.filtreleriUygula();
      this.showToast('Beğenildi! ❤️');
    }
  }

  private urunSil(id: string) {
    if (confirm('Bu ürünü silmek istediğinizden emin misiniz?')) {
      const index = this.urunler.findIndex(u => u.id === id);
      if (index !== -1) {
        // Animasyon için sınıf ekle
        const kart = document.querySelector(`article[data-id="${id}"]`);
        kart?.classList.add('removing');
        
        setTimeout(() => {
          this.urunler.splice(index, 1);
          this.verileriKaydet();
          this.filtreleriUygula();
          this.showToast('Ürün silindi.', 'danger');
        }, 300);
      }
    }
  }

  private yorumEkle(id: string, metin: string) {
    if (!metin.trim()) return;
    const urun = this.urunler.find(u => u.id === id);
    if (urun) {
      urun.yorumlar.push({
        id: Date.now().toString(),
        metin: metin,
        zamanDamgasi: Date.now()
      });
      this.verileriKaydet();
      this.filtreleriUygula();
    }
  }

  private ekranaBas() {
    const konteyner = document.getElementById('productGrid') as HTMLElement;
    const istatistikPanel = document.getElementById('statsDisplay') as HTMLElement;
    
    // İstatistikler (Array.reduce kullanımı)
    const toplamUrun = this.urunler.length;
    const toplamBegeni = this.urunler.reduce((toplam, u) => toplam + u.begeniSayisi, 0);
    const toplamYorum = this.urunler.reduce((toplam, u) => toplam + u.yorumlar.length, 0);
    istatistikPanel.textContent = `Ürün: ${toplamUrun} | Beğeni: ${toplamBegeni} | Yorum: ${toplamYorum}`;

    if (this.filtrelenmisUrunler.length === 0) {
      konteyner.innerHTML = `
        <div class="empty-state">
          <h3>Henüz ürün yok, ilk paylaşımı sen yap!</h3>
          <p>Arama kriterlerinizi veya kategori filtrenizi değiştirmeyi deneyin.</p>
        </div>
      `;
      return;
    }

    konteyner.innerHTML = '';
    this.filtrelenmisUrunler.forEach(urun => {
      const kart = document.createElement('article');
      kart.className = 'product-card';
      kart.setAttribute('data-id', urun.id);
      
      const resimHtml = urun.resim 
        ? `<img src="${urun.resim}" class="product-img" alt="${urun.baslik}">` 
        : `<div class="product-img" style="background: var(--border); display: flex; align-items: center; justify-content: center; font-size: 3rem;">📦</div>`;

      kart.innerHTML = `
        ${resimHtml}
        <div class="card-content">
          <span class="category-tag" data-cat="${urun.kategori}">${urun.kategori}</span>
          <h3 class="product-title">${this.guvenliMetin(urun.baslik)}</h3>
          <p class="product-desc">${this.guvenliMetin(urun.aciklama)}</p>
          <div class="product-price">₺${urun.fiyat.toFixed(2)}</div>
        </div>
        <div class="card-actions">
          <div class="action-btns">
            <button class="like-btn" title="Beğen">
              <span>❤️</span>
              <span class="like-count">${urun.begeniSayisi}</span>
            </button>
            <button class="delete-btn" title="Sil">🗑️</button>
          </div>
          <span class="text-muted" style="font-size: 0.75rem">${new Date(urun.olusturulmaTarihi).toLocaleDateString('tr-TR')}</span>
        </div>
        <div class="comments-section">
          <ul class="comment-list">
            ${urun.yorumlar.map(y => `<li class="comment-item">${this.guvenliMetin(y.metin)}</li>`).join('')}
          </ul>
          <form class="comment-form">
            <input type="text" class="comment-input" placeholder="Yorum ekle..." required>
            <button type="submit" class="primary-btn comment-btn">Gönder</button>
          </form>
        </div>
      `;

      konteyner.appendChild(kart);
    });
  }

  private showToast(message: string, type: 'success' | 'danger' | 'info' = 'info') {
    const container = document.getElementById('toastContainer')!;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('removing');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  private guvenliMetin(str: string) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new ShareBoxApp();
});
